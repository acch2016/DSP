/**
	\file
	\brief
		This is the starter file of FlexTimer.
		In this file the FlexTimer is configured in overflow mode.
	\author J. Luis Pizano Escalante, luispizano@iteso.mx
	\date	7/09/2014
	\todo
	    Add configuration structures.
 */


#define FTM_FQ 10500000

#include "FlexTimer.h"

//uint8 hola = FALSE;

typedef enum {
	PRIMER_VALOR,
	SEGUNDO_VALOR,
}ValorDefinitionType;

/** Variable to contain the FTM0 counter value*/
uint32 dummycounter = 0;
volatile float cntTimerValue = 0;
volatile float cntTimerValue2 = 0;
volatile uint8 flag = 0;
 float period = 0;
 float  frequency = 0;

void FTM0_IRQHandler(){

	FTM0_C0SC &= ~FLEX_TIMER_CHF;
	//dummycounter = FTM0_C0V;
	if (PRIMER_VALOR == flag){
		cntTimerValue = (float)FTM0_C0V;
		flag++;
	} else if (SEGUNDO_VALOR == flag) {
		cntTimerValue2 = (float)FTM0_C0V;

		freq_per();

		flag = 0;
	}
	//hola = TRUE;
}
void freq_per(){
    		period=(cntTimerValue2-cntTimerValue)*(1/FTM_FQ);
			frequency=(1/period);

}
void FTM_Init()
{
	/**Clock gating for FlexTimer*/
	SIM_SCGC6 |= FLEX_TIMER_0_CLOCK_GATING;
	//SIM_SCGC6|=0x03000000; //enable FTM0 and FTM0 module clock
	/**When write protection is enabled (WPDIS = 0), write protected bits cannot be written. 
	 * When write protection is disabled (WPDIS = 1), write protected bits can be written.*/
	FTM0_SC=0x00;
	FTM0_MODE |= FLEX_TIMER_WPDIS;


	//FTM0_MODE |= FTM_MODE_CAPTEST_MASK;

	FTM0_COMBINE &= ~(FTM_COMBINE_DECAPEN0_MASK | FTM_COMBINE_COMBINE0_MASK);

	//FTM0_SC &= ~(FTM_SC_CPWMS_MASK);/**Center-Aligned PWM Select / FTM counter operates in Up Counting mode.*/
	/**Configure FlexTimer in INPUT CAPTURE in toggle mode*/
	FTM0_C0SC |=  FTM_CnSC_ELSA_MASK;


	//FTM0_MOD = 0xFF; //Max frequency

	FTM0_C0SC |= FTM_CnSC_CHIE_MASK;/**Channel Interrupt Enable / Enables channel interrupts*/
	/**Assign channel value register with a predefined value*/
	//


	/**This field is write protected. It can be written only when MODE[WPDIS] = 1.*/
	/** 
	 * 0 Only the TPM-compatible registers (first set of registers) can be used without any restriction. Do not
	 * use the FTM-specific registers.
	 * 1 All registers including the FTM-specific registers (second set of registers) are available for use with no restrictions.*/
	//FTM0_MODE &= ~FLEX_TIMER_FTMEN;
	//FTM0_MODE |= FLEX_TIMER_FTMEN;
	/**Selects the FTM behavior in BDM mode.In this case in functional mode*/
	FTM0_CONF |= FTM_CONF_BDMMODE(3);

	/**Assign modulo register with a predefined value*/
	//FTM0_MOD = 0x0F;
	/**Configure FlexTimer in output compare in toggle mode*/
	//FTM0_C0SC = FLEX_TIMER_MSA | FLEX_TIMER_ELSA;
	/**Assign channel value register with a predefined value*/
	//FTM0_C0V = 0x00;
	/**Select clock source and prescaler*/
	FTM0_SC |= FLEX_TIMER_CLKS_1 | FLEX_TIMER_PS_2;
}


