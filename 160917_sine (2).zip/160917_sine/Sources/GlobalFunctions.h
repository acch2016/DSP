/*
 * GlobalFunctions.h
 *
 *  Created on: Jun 22, 2014
 *      Author: Luis
 */

#ifndef GLOBALFUNCTIONS_H_
#define GLOBALFUNCTIONS_H_

#include "GPIO.h"
#include "DataTypeDefinitions.h"

void delay(uint16);
uint16 cociente;


#endif /* GLOBALFUNCTIONS_H_ */
