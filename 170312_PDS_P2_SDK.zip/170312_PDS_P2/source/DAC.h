/*
 * DAC.h
 *
 *  Created on: 12/3/2017
 *      Author: alejandrocanale
 */

#ifndef SOURCES_DAC_H_
#define SOURCES_DAC_H_

#include "DataTypeDefinitions.h"



void  DAC_Init(void);

void DAC_DataRegister(uint32 data);



#endif /* SOURCES_DAC_H_ */
