/*
 * GlobalFunctions.h
 *
 *  Created on: Sep 14, 2014
 *      Author: Luis
 */

#ifndef GLOBALFUNCTIONS_H_
#define GLOBALFUNCTIONS_H_

#include "DataTypeDefinitions.h"

void delay(uint16);

#endif /* GLOBALFUNCTIONS_H_ */
