var _global_functions_8h =
[
    [ "delay", "_global_functions_8h.html#abd8394c9dd45704f8b8bc20400bc89f7", null ]
];