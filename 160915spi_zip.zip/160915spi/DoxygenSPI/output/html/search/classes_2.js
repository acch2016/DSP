var searchData=
[
  ['spi_5fconfigtype',['SPI_ConfigType',['../struct_s_p_i___config_type.html',1,'']]]
];
