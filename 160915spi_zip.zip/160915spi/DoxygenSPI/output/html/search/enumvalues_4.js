var searchData=
[
  ['true',['TRUE',['../_data_type_definitions_8h.html#a20f82124c82b6f5686a7fce454ef9089aa82764c3079aea4e60c80e45befbb839',1,'DataTypeDefinitions.h']]]
];
