var searchData=
[
  ['false',['FALSE',['../_data_type_definitions_8h.html#a20f82124c82b6f5686a7fce454ef9089aa1e095cc966dbecf6a0d8aad75348d1a',1,'DataTypeDefinitions.h']]]
];
