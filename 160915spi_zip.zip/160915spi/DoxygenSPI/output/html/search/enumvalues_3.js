var searchData=
[
  ['spi_5f0',['SPI_0',['../_s_p_i_8h.html#a76504d7e13d22387994b4d278ebfafaca92559105229aa7c103fa22311c4343da',1,'SPI.h']]],
  ['spi_5f1',['SPI_1',['../_s_p_i_8h.html#a76504d7e13d22387994b4d278ebfafacaa4b24f86e59b845990862af6481c321f',1,'SPI.h']]],
  ['spi_5f2',['SPI_2',['../_s_p_i_8h.html#a76504d7e13d22387994b4d278ebfafaca78d05bc33881e02031f9bb60dc5312ee',1,'SPI.h']]],
  ['spi_5fdisable_5ffifo',['SPI_DISABLE_FIFO',['../_s_p_i_8h.html#ad116c6bfe72af0c7b848a576f2b61585adf96a1c6b5b2304aeaa5cc2477475a4d',1,'SPI.h']]],
  ['spi_5fenable_5ffifo',['SPI_ENABLE_FIFO',['../_s_p_i_8h.html#ad116c6bfe72af0c7b848a576f2b61585a7e46e76eb737acc4581609dcda564cbe',1,'SPI.h']]],
  ['spi_5fhigh_5fphase',['SPI_HIGH_PHASE',['../_s_p_i_8h.html#ae94f7ff08c149dcdb8e063f7dc059900a209e694aca1701ffd4277f9e8d5400c4',1,'SPI.h']]],
  ['spi_5fhigh_5fpolarity',['SPI_HIGH_POLARITY',['../_s_p_i_8h.html#a61f52af8efd9eb12e24c1cf0a7bce4d6a7529af12983200135f4c5ec26498ca36',1,'SPI.h']]],
  ['spi_5flow_5fphase',['SPI_LOW_PHASE',['../_s_p_i_8h.html#ae94f7ff08c149dcdb8e063f7dc059900af5c27fcee63c78b6d39e0da23eede0c0',1,'SPI.h']]],
  ['spi_5flow_5fpolarity',['SPI_LOW_POLARITY',['../_s_p_i_8h.html#a61f52af8efd9eb12e24c1cf0a7bce4d6a457a7ebf19a7da45b7f048ff40e1802a',1,'SPI.h']]],
  ['spi_5flsm',['SPI_LSM',['../_s_p_i_8h.html#a2fa069a2dca622dad0b9dcbffd72d6f8a1aadbcb136201ddd92e05428c8c1042c',1,'SPI.h']]],
  ['spi_5fmaster',['SPI_MASTER',['../_s_p_i_8h.html#a0df6980c6cb97e5e1c9ff5f29ead571fa84379dc90398ca075038c8d5ee465f6a',1,'SPI.h']]],
  ['spi_5fmsb',['SPI_MSB',['../_s_p_i_8h.html#a2fa069a2dca622dad0b9dcbffd72d6f8a1eae4fe3047bf4fbef593e1d39562f45',1,'SPI.h']]],
  ['spi_5fslave',['SPI_SLAVE',['../_s_p_i_8h.html#a0df6980c6cb97e5e1c9ff5f29ead571fabc98c1546fe12d3fceb1f86cf670faa9',1,'SPI.h']]]
];
