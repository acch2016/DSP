var searchData=
[
  ['gpioforspitype',['GPIOForSPIType',['../struct_g_p_i_o_for_s_p_i_type.html',1,'']]]
];
