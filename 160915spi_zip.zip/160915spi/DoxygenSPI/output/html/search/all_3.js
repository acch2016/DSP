var searchData=
[
  ['data_5for_5fcmd_5fpin',['DATA_OR_CMD_PIN',['../_l_c_d_nokia5110_8h.html#aceb1b638f6ba9158dbebcda20c191d24',1,'LCDNokia5110.h']]],
  ['datatypedefinitions_2eh',['DataTypeDefinitions.h',['../_data_type_definitions_8h.html',1,'']]],
  ['delay',['delay',['../_global_functions_8c.html#aa7fa622ced5687f8351d589e9402b251',1,'delay(uint16 delay):&#160;GlobalFunctions.c'],['../_global_functions_8h.html#abd8394c9dd45704f8b8bc20400bc89f7',1,'delay(uint16):&#160;GlobalFunctions.c']]],
  ['dma_5feither_5fedge',['DMA_EITHER_EDGE',['../_g_p_i_o_8h.html#a3bee3c71e3c352e04f1fd9c1021f2474',1,'GPIO.h']]],
  ['dma_5ffalling_5fedge',['DMA_FALLING_EDGE',['../_g_p_i_o_8h.html#acfa3f39279bc6e6e96d5dcb80c5b14ff',1,'GPIO.h']]],
  ['dma_5frising_5fedge',['DMA_RISING_EDGE',['../_g_p_i_o_8h.html#a78ead29f5684329b6c2612a8495c0897',1,'GPIO.h']]]
];
