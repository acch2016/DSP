var searchData=
[
  ['sint16',['sint16',['../_data_type_definitions_8h.html#a64d7f11d46d559e2d8acf6d5218af066',1,'DataTypeDefinitions.h']]],
  ['sint32',['sint32',['../_data_type_definitions_8h.html#a2bdbdc0c5bde9a23853468061a8538ac',1,'DataTypeDefinitions.h']]],
  ['sint8',['sint8',['../_data_type_definitions_8h.html#af0b2e0a6b30e2f691ebfd19b6dcbadfa',1,'DataTypeDefinitions.h']]]
];
