var struct_g_p_i_o_for_s_p_i_type =
[
    [ "GPIO_portName", "struct_g_p_i_o_for_s_p_i_type.html#a6cbcf6cb04281ddd2fbe6ca040b7acbd", null ],
    [ "SPI_clk", "struct_g_p_i_o_for_s_p_i_type.html#ad97c70b62a398d903950203f6bebbe71", null ],
    [ "SPI_Sout", "struct_g_p_i_o_for_s_p_i_type.html#a093ab3c69d61e5badc3ce2251e07f3f0", null ]
];