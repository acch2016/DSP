var files =
[
    [ "DataTypeDefinitions.h", "_data_type_definitions_8h.html", "_data_type_definitions_8h" ],
    [ "GlobalFunctions.c", "_global_functions_8c.html", "_global_functions_8c" ],
    [ "GlobalFunctions.h", "_global_functions_8h.html", "_global_functions_8h" ],
    [ "GPIO.c", "_g_p_i_o_8c.html", "_g_p_i_o_8c" ],
    [ "GPIO.h", "_g_p_i_o_8h.html", "_g_p_i_o_8h" ],
    [ "LCDNokia5110.c", "_l_c_d_nokia5110_8c.html", "_l_c_d_nokia5110_8c" ],
    [ "LCDNokia5110.h", "_l_c_d_nokia5110_8h.html", "_l_c_d_nokia5110_8h" ],
    [ "LCDNokia5110Images.c", "_l_c_d_nokia5110_images_8c.html", "_l_c_d_nokia5110_images_8c" ],
    [ "LCDNokia5110Images.h", "_l_c_d_nokia5110_images_8h.html", null ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "SPI.c", "_s_p_i_8c.html", "_s_p_i_8c" ],
    [ "SPI.h", "_s_p_i_8h.html", "_s_p_i_8h" ]
];