var annotated_dup =
[
    [ "Flags", "union_flags.html", "union_flags" ],
    [ "GPIOForSPIType", "struct_g_p_i_o_for_s_p_i_type.html", "struct_g_p_i_o_for_s_p_i_type" ],
    [ "SPI_ConfigType", "struct_s_p_i___config_type.html", "struct_s_p_i___config_type" ]
];