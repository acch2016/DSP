var main_8c =
[
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "ITESO", "main_8c.html#a889a77c9432826b4b89075c46a407162", null ],
    [ "SPI_Config", "main_8c.html#aea9e676e30d1448b179b3a1e70af79fe", null ]
];