var union_flags =
[
    [ "AllFlags", "union_flags.html#af6e55ff01e0496af9a871bc15d321ce2", null ],
    [ "Flagfield", "union_flags.html#a0db6f79249f7df0d3ccf731f00febdf2", null ],
    [ "FlagPortA", "union_flags.html#a0097a50dd52996e1fdb0ee58a04de0b1", null ],
    [ "FlagPortB", "union_flags.html#abe8d68364df6ddc9dda3d2f60ba8021d", null ],
    [ "FlagPortC", "union_flags.html#a26529ce3dfd4a5f5016d15a7e155ac1f", null ]
];