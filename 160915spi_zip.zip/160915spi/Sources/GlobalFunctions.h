/*
 * GlobalFunctions.h
 *
 *  Created on: Jun 22, 2014
 *      Author: Luis
 */

#ifndef GLOBALFUNCTIONS_H_
#define GLOBALFUNCTIONS_H_

#include "GPIO.h"
#include "DataTypeDefinitions.h"

void delay(uint16);



#endif /* GLOBALFUNCTIONS_H_ */
