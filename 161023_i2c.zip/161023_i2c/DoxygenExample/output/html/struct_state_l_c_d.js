var struct_state_l_c_d =
[
    [ "fptrLCD", "struct_state_l_c_d.html#aee2c8c379740dd639ee4008f4ed0a31d", null ],
    [ "next", "struct_state_l_c_d.html#ae88110b85e944fd7f83954e8e84aec20", null ]
];