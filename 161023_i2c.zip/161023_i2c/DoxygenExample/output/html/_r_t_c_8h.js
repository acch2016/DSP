var _r_t_c_8h =
[
    [ "FormatRTCType", "_r_t_c_8h.html#afed004ac3f3f732dff18dbef9f15f3e8", [
      [ "H24", "_r_t_c_8h.html#afed004ac3f3f732dff18dbef9f15f3e8a1c6a175cf326a606a8351d7eefc479bb", null ],
      [ "H12", "_r_t_c_8h.html#afed004ac3f3f732dff18dbef9f15f3e8a76396007202b58b4547a162670a4ebc6", null ]
    ] ],
    [ "modifyYears", "_r_t_c_8h.html#a98574ba261686e9bec07030c96a4eb92", null ],
    [ "RTC_changeFormat", "_r_t_c_8h.html#a0cad1d9c119a9fecac4dd023423fccf7", null ],
    [ "RTC_get_Day", "_r_t_c_8h.html#aba4f818e4a19cef08b3e4aa9cdfe38a5", null ],
    [ "RTC_get_Hour", "_r_t_c_8h.html#aaec022c07acfd9b12270e6ddd8ac2c8a", null ],
    [ "RTC_get_Minutes", "_r_t_c_8h.html#a74c11cfe5c615e495e94fa1980bc7e91", null ],
    [ "RTC_get_Month", "_r_t_c_8h.html#abdbc7834418dcce86aa455601fd96d9b", null ],
    [ "RTC_get_Seconds", "_r_t_c_8h.html#adebd8454ab83907563fb817effe1a72e", null ],
    [ "RTC_get_String_Date", "_r_t_c_8h.html#aa76b49f8571738120a08a7f3d564d065", null ],
    [ "RTC_get_String_Hour", "_r_t_c_8h.html#a8cb2ebc7b464f6eb7231a5e5b98400af", null ],
    [ "RTC_get_Year", "_r_t_c_8h.html#aa2db0ab0906931785bca0a1cd841c550", null ],
    [ "RTC_Init", "_r_t_c_8h.html#aaacc65d028b006a961eef7ab69b903c5", null ],
    [ "RTC_readData", "_r_t_c_8h.html#a9a98cbc7a571a7ac2a3a5266a80ec235", null ],
    [ "RTC_set_Day", "_r_t_c_8h.html#ad4b203b3404254c6319603e03156b2d1", null ],
    [ "RTC_set_Hour", "_r_t_c_8h.html#a6e94a2086fa763c3283531082de0d59d", null ],
    [ "RTC_set_Minutes", "_r_t_c_8h.html#afd3ad0dd1f6c44e262a1d2deba859ba5", null ],
    [ "RTC_set_Month", "_r_t_c_8h.html#ae6efcfaec1658f8938374f4b556c3b06", null ],
    [ "RTC_set_Year", "_r_t_c_8h.html#aafe05891357671fe242e7ba563521958", null ],
    [ "RTC_writeData", "_r_t_c_8h.html#a72b3cd437d82fa62ffe9185c069c0f57", null ]
];