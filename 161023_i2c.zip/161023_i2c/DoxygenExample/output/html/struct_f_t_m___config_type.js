var struct_f_t_m___config_type =
[
    [ "FTM_C0SC_Mask", "struct_f_t_m___config_type.html#af85f8206cd02b75c46ad9d2b99ec72bd", null ],
    [ "FTM_Channel", "struct_f_t_m___config_type.html#ad203a6848528cf5be795302bca4bc9b9", null ],
    [ "FTM_ClockMask", "struct_f_t_m___config_type.html#a48c6629dca6d3324d9a050daea2780eb", null ],
    [ "FTM_COMBINE_Mask", "struct_f_t_m___config_type.html#a0666cd260cb1aaf60a668874664add44", null ],
    [ "FTM_CONF_Mask", "struct_f_t_m___config_type.html#adfa561ee8400cdf62a203c696ef6361b", null ],
    [ "FTM_MOD_Mask", "struct_f_t_m___config_type.html#ad9c2308774fa716793fa4e31e585d294", null ],
    [ "FTM_MODE_Mask", "struct_f_t_m___config_type.html#a72a89db25262c833496ad263c0e9e4c9", null ],
    [ "FTM_SC_Mask", "struct_f_t_m___config_type.html#a50158714bff661387f655f6ab2144cc0", null ]
];