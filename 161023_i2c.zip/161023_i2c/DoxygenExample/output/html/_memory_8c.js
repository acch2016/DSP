var _memory_8c =
[
    [ "BDH_MASK", "_memory_8c.html#a5d3083db5c6fcd0245240bd8f7896c07", null ],
    [ "BDH_SHIFT", "_memory_8c.html#a8e0a396e244de63d404cb30854d1afc1", null ],
    [ "BDL_MASK", "_memory_8c.html#a990ea92b72a361eed51b98acf443429c", null ],
    [ "Memory_Read", "_memory_8c.html#a9ed4e4373f4034994e5e00026ee7b45f", null ],
    [ "Memory_Write", "_memory_8c.html#a702e1641aee2c199adb0719803c3e776", null ]
];