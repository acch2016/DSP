var struct_u_a_r_t___mail_box_type =
[
    [ "flag", "struct_u_a_r_t___mail_box_type.html#af11e40d15a1361229a78e772af5b3c94", null ],
    [ "mailBox", "struct_u_a_r_t___mail_box_type.html#ab7c430379c5c710e21e9c9b653b51256", null ]
];