var struct_state =
[
    [ "fptrScreen", "struct_state.html#aa11dd1320ba788c64262ab597d74d017", null ],
    [ "next", "struct_state.html#a1cb622536b7ccb8f0fc8d61b79906e9b", null ]
];