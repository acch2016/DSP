var _global_functions_8h =
[
    [ "BCDtoBinary", "_global_functions_8h.html#a94e3346edf9d582c0fc48b57b831bcb5", null ],
    [ "BinarytoHex", "_global_functions_8h.html#a8ad361c0ad546131a7cb5b90d84a4a09", null ],
    [ "CleanArray", "_global_functions_8h.html#a0071e12287aece481b9ad59f8cb7338d", null ],
    [ "delay", "_global_functions_8h.html#abd8394c9dd45704f8b8bc20400bc89f7", null ],
    [ "HextoBinary", "_global_functions_8h.html#a10f6813b92b9cfb51fe4b518b90d4317", null ]
];