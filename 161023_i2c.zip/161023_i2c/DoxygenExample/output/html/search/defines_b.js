var searchData=
[
  ['no_5foscinit',['NO_OSCINIT',['../_m_c_g_8h.html#a2554d7b33a279f9b4e4da4bb730198dc',1,'MCG.h']]],
  ['noon_5fmask',['NOON_MASK',['../_r_t_c_8c.html#ad88aa147f7c7a46f6fde96e648395dc1',1,'RTC.c']]]
];
