var searchData=
[
  ['spi_5fchannel',['SPI_Channel',['../struct_s_p_i___config_type.html#ae09a3a0be9756c9a02834592ccbbd505',1,'SPI_ConfigType']]],
  ['spi_5fclk',['SPI_clk',['../struct_g_p_i_o_for_s_p_i_type.html#ad97c70b62a398d903950203f6bebbe71',1,'GPIOForSPIType']]],
  ['spi_5fctar',['SPI_CTAR',['../_s_p_i_8c.html#a6a4caf0b515498f176ea2c13e952cac1',1,'SPI.c']]],
  ['spi_5fenablefifo',['SPI_EnableFIFO',['../struct_s_p_i___config_type.html#a62da0169faa55b3f872d094dad1288b0',1,'SPI_ConfigType']]],
  ['spi_5flsmormsb',['SPI_LSMorMSB',['../struct_s_p_i___config_type.html#ab0d82c429ae61272760df3fff9061513',1,'SPI_ConfigType']]],
  ['spi_5fmaster',['SPI_Master',['../struct_s_p_i___config_type.html#a6d64386cb1375f99921b88ebd1473172',1,'SPI_ConfigType']]],
  ['spi_5fphase',['SPI_Phase',['../struct_s_p_i___config_type.html#a0a13eb49b664d7b3bd0f8348c4520a99',1,'SPI_ConfigType']]],
  ['spi_5fpolarity',['SPI_Polarity',['../struct_s_p_i___config_type.html#a0ffcdd0962ea071fa1ae1919f2a83276',1,'SPI_ConfigType']]],
  ['spi_5fsout',['SPI_Sout',['../struct_g_p_i_o_for_s_p_i_type.html#a093ab3c69d61e5badc3ce2251e07f3f0',1,'GPIOForSPIType']]],
  ['spix_5fmcr',['SPIx_MCR',['../_s_p_i_8c.html#a526c76fa6bc4a6ad5347d5b5243866fd',1,'SPI.c']]]
];
