var searchData=
[
  ['what_5fmcg_5fmode',['what_mcg_mode',['../_m_c_g_8c.html#a721d6c6108a90f104913f9c3dc01cac8',1,'what_mcg_mode(void):&#160;MCG.c'],['../_m_c_g_8h.html#a721d6c6108a90f104913f9c3dc01cac8',1,'what_mcg_mode(void):&#160;MCG.c']]],
  ['writememi2c_5fstate',['writeMemI2c_State',['../menu_8c.html#a958aa1815ff4ad7444defcc83b9a3aed',1,'writeMemI2c_State(UART_ChannelType uartChannel):&#160;menu.c'],['../menu_8h.html#a958aa1815ff4ad7444defcc83b9a3aed',1,'writeMemI2c_State(UART_ChannelType uartChannel):&#160;menu.c']]]
];
