var searchData=
[
  ['nvic_5fenableinterruptandpriotity',['NVIC_enableInterruptAndPriotity',['../_n_v_i_c_8c.html#a1a4e74e5f147d23a9070d864c4f20606',1,'NVIC_enableInterruptAndPriotity(InterruptType interruptNumber, PriorityLevelType priority):&#160;NVIC.c'],['../_n_v_i_c_8h.html#a1a4e74e5f147d23a9070d864c4f20606',1,'NVIC_enableInterruptAndPriotity(InterruptType interruptNumber, PriorityLevelType priority):&#160;NVIC.c']]],
  ['nvic_5fsetbasepri_5fthreshold',['NVIC_setBASEPRI_threshold',['../_n_v_i_c_8c.html#adabcb6ba7492c49a19f0da49558394a5',1,'NVIC_setBASEPRI_threshold(PriorityLevelType priority):&#160;NVIC.c'],['../_n_v_i_c_8h.html#adabcb6ba7492c49a19f0da49558394a5',1,'NVIC_setBASEPRI_threshold(PriorityLevelType priority):&#160;NVIC.c']]]
];
