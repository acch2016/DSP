var searchData=
[
  ['baudrate',['baudrate',['../struct_s_p_i___config_type.html#a42f49748a986550b6398015dc5cd7c40',1,'SPI_ConfigType']]]
];
