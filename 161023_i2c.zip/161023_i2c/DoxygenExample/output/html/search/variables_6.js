var searchData=
[
  ['i2cx_5fc1',['I2Cx_C1',['../_i2_c_8c.html#a71fa723431ccc734b756b4b85ad6e04f',1,'I2C.c']]],
  ['i2cx_5fd',['I2Cx_D',['../_i2_c_8c.html#a0a939e2bbd106151953f6cbc382111a1',1,'I2C.c']]],
  ['i2cx_5ff',['I2Cx_F',['../_i2_c_8c.html#aa5666203fd0b2b52d5ff432b6ef37c57',1,'I2C.c']]],
  ['i2cx_5fs',['I2Cx_S',['../_i2_c_8c.html#a6592252f4ef003e2e378f0140a711cf1',1,'I2C.c']]],
  ['iteso',['ITESO',['../_l_c_d_nokia5110_images_8c.html#a69731923371f57987343f36de2e88aa0',1,'LCDNokia5110Images.c']]]
];
