var searchData=
[
  ['atc',['atc',['../_m_c_g_8c.html#ad61f1befd520b09a730c781767240a56',1,'atc(unsigned char irc_select, int irc_freq, int mcg_out_freq):&#160;MCG.c'],['../_m_c_g_8h.html#ad61f1befd520b09a730c781767240a56',1,'atc(unsigned char irc_select, int irc_freq, int mcg_out_freq):&#160;MCG.c']]]
];
