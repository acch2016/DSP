var searchData=
[
  ['canned_5fosc',['CANNED_OSC',['../_m_c_g_8h.html#a946a83ca831b72c2b9563c07e75b6724',1,'MCG.h']]],
  ['clk0_5ftype',['CLK0_TYPE',['../main_8c.html#a57b23a4a08917373b6baaf44b7107627',1,'main.c']]],
  ['clk_5ffreq_5fhz',['CLK_FREQ_HZ',['../main_8c.html#a89bf1cb7ece86f095f3809b15a60e29c',1,'main.c']]],
  ['communication_5ft1_5ft2',['COMMUNICATION_T1_T2',['../menu_8h.html#a3bef6ca9c40f62d94472b96f1c418333',1,'menu.h']]],
  ['crystal',['CRYSTAL',['../_m_c_g_8h.html#a12cfaf33fd0b088a66297996b1dfea45',1,'MCG.h']]],
  ['crystal_5fosc',['CRYSTAL_OSC',['../main_8c.html#a0d4569f00223adb0ecf9698f4940b8d4',1,'main.c']]]
];
