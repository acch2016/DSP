var searchData=
[
  ['screenfsm',['screenFSM',['../menu_8c.html#a9f08e939768e1bd8116f5a1c784c6300',1,'screenFSM():&#160;menu.c'],['../menu_8h.html#a9f08e939768e1bd8116f5a1c784c6300',1,'screenFSM():&#160;menu.c']]],
  ['screenfsm_5fbluetooth',['screenFSM_Bluetooth',['../menu_8c.html#a79dcf33543be1f00c258d3b3e1c71304',1,'screenFSM_Bluetooth():&#160;menu.c'],['../menu_8h.html#a79dcf33543be1f00c258d3b3e1c71304',1,'screenFSM_Bluetooth():&#160;menu.c']]],
  ['setdate',['setDate',['../_f_s_m_l_c_d_8c.html#af059e8fa50704e2c0bec8995044bc85e',1,'setDate():&#160;FSMLCD.c'],['../_f_s_m_l_c_d_8h.html#af059e8fa50704e2c0bec8995044bc85e',1,'setDate():&#160;FSMLCD.c']]],
  ['setdate_5fstate',['setDate_State',['../menu_8c.html#a1d0928b273269905fd0b0c4f6b8194bb',1,'setDate_State(UART_ChannelType uartChannel):&#160;menu.c'],['../menu_8h.html#a1d0928b273269905fd0b0c4f6b8194bb',1,'setDate_State(UART_ChannelType uartChannel):&#160;menu.c']]],
  ['setechoflag',['setEchoFlag',['../_f_s_m_l_c_d_8c.html#a5750782333e6723f2b59a1f2cf77d2d9',1,'setEchoFlag():&#160;FSMLCD.c'],['../_f_s_m_l_c_d_8h.html#a5750782333e6723f2b59a1f2cf77d2d9',1,'setEchoFlag():&#160;FSMLCD.c']]],
  ['sethour',['setHour',['../_f_s_m_l_c_d_8c.html#aaea0e23d6555c9ede1e61133c8e2cfe6',1,'setHour():&#160;FSMLCD.c'],['../_f_s_m_l_c_d_8h.html#aaea0e23d6555c9ede1e61133c8e2cfe6',1,'setHour():&#160;FSMLCD.c']]],
  ['sethour_5fstate',['setHour_State',['../menu_8c.html#ab2e48e2d5cd8873d3eed9464df6e23c9',1,'setHour_State(UART_ChannelType uartChannel):&#160;menu.c'],['../menu_8h.html#ab2e48e2d5cd8873d3eed9464df6e23c9',1,'setHour_State(UART_ChannelType uartChannel):&#160;menu.c']]],
  ['spi_5fclockpolarity',['SPI_clockPolarity',['../_s_p_i_8c.html#af5744b76088520e4d616d70a67fa9374',1,'SPI.c']]],
  ['spi_5fenable',['SPI_enable',['../_s_p_i_8c.html#aa8569eff93c8e6e683029aead54bc3ba',1,'SPI.c']]],
  ['spi_5finit',['SPI_init',['../_s_p_i_8c.html#aa72983bdb1bcfc055cea98c7501cc930',1,'SPI_init(const SPI_ConfigType *SPI_Config):&#160;SPI.c'],['../_s_p_i_8h.html#a31152f14e43ecf7368324eb0a0542dd5',1,'SPI_init(const SPI_ConfigType *):&#160;SPI.c']]],
  ['spi_5fsendonebyte',['SPI_sendOneByte',['../_s_p_i_8c.html#a8ca8cd04c9bc2ef898aee5d38b829642',1,'SPI_sendOneByte(uint8 Data):&#160;SPI.c'],['../_s_p_i_8h.html#a8ca8cd04c9bc2ef898aee5d38b829642',1,'SPI_sendOneByte(uint8 Data):&#160;SPI.c']]],
  ['spi_5fstarttranference',['SPI_startTranference',['../_s_p_i_8c.html#a747d339e8353778bf7f8635a91d0a5f9',1,'SPI_startTranference(SPI_ChannelType channel):&#160;SPI.c'],['../_s_p_i_8h.html#a747d339e8353778bf7f8635a91d0a5f9',1,'SPI_startTranference(SPI_ChannelType channel):&#160;SPI.c']]],
  ['spi_5fstoptranference',['SPI_stopTranference',['../_s_p_i_8c.html#a12e009cdc7cb64988ecf0814c3524f88',1,'SPI_stopTranference(SPI_ChannelType channel):&#160;SPI.c'],['../_s_p_i_8h.html#a12e009cdc7cb64988ecf0814c3524f88',1,'SPI_stopTranference(SPI_ChannelType channel):&#160;SPI.c']]]
];
