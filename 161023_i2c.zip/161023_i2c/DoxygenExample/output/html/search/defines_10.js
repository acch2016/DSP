var searchData=
[
  ['tens_5fshifts',['TENS_SHIFTS',['../_r_t_c_8c.html#a786ec50ae60bfa43d17dce3ae5e0cb81',1,'RTC.c']]]
];
