var searchData=
[
  ['spi_5fchanneltype',['SPI_ChannelType',['../_s_p_i_8h.html#a76504d7e13d22387994b4d278ebfafac',1,'SPI.h']]],
  ['spi_5fenablefifotype',['SPI_EnableFIFOType',['../_s_p_i_8h.html#ad116c6bfe72af0c7b848a576f2b61585',1,'SPI.h']]],
  ['spi_5flsmormsbtype',['SPI_LSMorMSBType',['../_s_p_i_8h.html#a2fa069a2dca622dad0b9dcbffd72d6f8',1,'SPI.h']]],
  ['spi_5fmastertype',['SPI_MasterType',['../_s_p_i_8h.html#a0df6980c6cb97e5e1c9ff5f29ead571f',1,'SPI.h']]],
  ['spi_5fphasetype',['SPI_PhaseType',['../_s_p_i_8h.html#ae94f7ff08c149dcdb8e063f7dc059900',1,'SPI.h']]],
  ['spi_5fpolaritytype',['SPI_PolarityType',['../_s_p_i_8h.html#a61f52af8efd9eb12e24c1cf0a7bce4d6',1,'SPI.h']]]
];
