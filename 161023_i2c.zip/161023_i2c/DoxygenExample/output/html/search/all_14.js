var searchData=
[
  ['wdog_5for_5fewm_5firq',['WDOG_OR_EWM_IRQ',['../_n_v_i_c_8h.html#a05657f3aa85721814ee368a0eded8513a58bd4b95c329d3d610961b674c4bbca1',1,'NVIC.h']]],
  ['what_5fmcg_5fmode',['what_mcg_mode',['../_m_c_g_8c.html#a721d6c6108a90f104913f9c3dc01cac8',1,'what_mcg_mode(void):&#160;MCG.c'],['../_m_c_g_8h.html#a721d6c6108a90f104913f9c3dc01cac8',1,'what_mcg_mode(void):&#160;MCG.c']]],
  ['write_5fmem_5fi2c',['WRITE_MEM_I2C',['../menu_8h.html#a6cbb23af2a225e9e373f65093921e627',1,'menu.h']]],
  ['writememi2c_5fstate',['writeMemI2c_State',['../menu_8c.html#a958aa1815ff4ad7444defcc83b9a3aed',1,'writeMemI2c_State(UART_ChannelType uartChannel):&#160;menu.c'],['../menu_8h.html#a958aa1815ff4ad7444defcc83b9a3aed',1,'writeMemI2c_State(UART_ChannelType uartChannel):&#160;menu.c']]]
];
