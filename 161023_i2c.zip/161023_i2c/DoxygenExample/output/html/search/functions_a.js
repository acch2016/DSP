var searchData=
[
  ['main',['main',['../main_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.c']]],
  ['memory_5fread',['Memory_Read',['../_memory_8c.html#a9ed4e4373f4034994e5e00026ee7b45f',1,'Memory_Read(uint16 Address, uint8 numBytes, uint8 Data[]):&#160;Memory.c'],['../_memory_8h.html#a9ed4e4373f4034994e5e00026ee7b45f',1,'Memory_Read(uint16 Address, uint8 numBytes, uint8 Data[]):&#160;Memory.c']]],
  ['memory_5fwrite',['Memory_Write',['../_memory_8c.html#a702e1641aee2c199adb0719803c3e776',1,'Memory_Write(uint16 Address, uint8 data[]):&#160;Memory.c'],['../_memory_8h.html#ab88efa8cca65c4643e1d25a06647040c',1,'Memory_Write(uint16 Address, uint8 *data):&#160;Memory.h']]],
  ['menulcd',['menuLCD',['../_f_s_m_l_c_d_8c.html#ae767c1c2905629e76afaf1bdfde086e0',1,'menuLCD():&#160;FSMLCD.c'],['../_f_s_m_l_c_d_8h.html#ae767c1c2905629e76afaf1bdfde086e0',1,'menuLCD():&#160;FSMLCD.c']]],
  ['menustate_5fuartx',['menuState_UARTx',['../menu_8c.html#a504975bba09dfde91a2c9ee6d2370c07',1,'menuState_UARTx(UART_ChannelType uartChannel):&#160;menu.c'],['../menu_8h.html#a504975bba09dfde91a2c9ee6d2370c07',1,'menuState_UARTx(UART_ChannelType uartChannel):&#160;menu.c']]],
  ['modifyyears',['modifyYears',['../_r_t_c_8c.html#a98574ba261686e9bec07030c96a4eb92',1,'modifyYears(sint8 yeah[]):&#160;RTC.c'],['../_r_t_c_8h.html#a98574ba261686e9bec07030c96a4eb92',1,'modifyYears(sint8 yeah[]):&#160;RTC.c']]]
];
