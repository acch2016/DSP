var searchData=
[
  ['lcd_5fcmd',['LCD_CMD',['../_l_c_d_nokia5110_8h.html#a28893b8aae31c65dfc6f5d478e225a2d',1,'LCDNokia5110.h']]],
  ['lcd_5fdata',['LCD_DATA',['../_l_c_d_nokia5110_8h.html#a25e9d818788f36ed74d7c4579f87f2a6',1,'LCDNokia5110.h']]],
  ['lcd_5fx',['LCD_X',['../_l_c_d_nokia5110_8h.html#a808ffb5b80958b23f08910c0f38c53d3',1,'LCDNokia5110.h']]],
  ['lcd_5fy',['LCD_Y',['../_l_c_d_nokia5110_8h.html#ae5070c3ce78b96d41f8e166abff903ed',1,'LCDNokia5110.h']]],
  ['low_5fpower',['LOW_POWER',['../main_8c.html#a35a08f33b3ae8fa5b76a37802c29bd05',1,'LOW_POWER():&#160;main.c'],['../_m_c_g_8h.html#a35a08f33b3ae8fa5b76a37802c29bd05',1,'LOW_POWER():&#160;MCG.h']]]
];
