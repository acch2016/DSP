var searchData=
[
  ['osc_5f0',['OSC_0',['../_m_c_g_8h.html#a89e726c2627926cffce61615cdec3f40',1,'MCG.h']]],
  ['osc_5f1',['OSC_1',['../_m_c_g_8h.html#ad544b9b7737d49e8088cea94c5227c55',1,'MCG.h']]],
  ['oscinit',['OSCINIT',['../_m_c_g_8h.html#ad00db2a4f47db469832511bdf43db344',1,'MCG.h']]]
];
