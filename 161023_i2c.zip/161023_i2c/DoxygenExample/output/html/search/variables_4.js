var searchData=
[
  ['gpio_5fportname',['GPIO_portName',['../struct_g_p_i_o_for_s_p_i_type.html#a6cbcf6cb04281ddd2fbe6ca040b7acbd',1,'GPIOForSPIType']]],
  ['gpioforspi',['GPIOForSPI',['../struct_s_p_i___config_type.html#abbc8299e8ac72f3d8145d07d8065b9f7',1,'SPI_ConfigType']]]
];
