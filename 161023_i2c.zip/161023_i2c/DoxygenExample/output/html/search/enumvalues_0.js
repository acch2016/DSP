var searchData=
[
  ['adc0_5firq',['ADC0_IRQ',['../_n_v_i_c_8h.html#a05657f3aa85721814ee368a0eded8513a28d40ba112a94553aa58096aff33a522',1,'NVIC.h']]],
  ['adc1_5firq',['ADC1_IRQ',['../_n_v_i_c_8h.html#a05657f3aa85721814ee368a0eded8513a2b29571a539ec2892c4ac985348d5ce3',1,'NVIC.h']]]
];
