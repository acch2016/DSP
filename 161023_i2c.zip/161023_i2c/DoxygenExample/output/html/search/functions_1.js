var searchData=
[
  ['bcdtobinary',['BCDtoBinary',['../_global_functions_8c.html#a5c3a036435ef4c8a94e78b9cc97fbe1f',1,'BCDtoBinary(uint8 character[], uint8 numChar):&#160;GlobalFunctions.c'],['../_global_functions_8h.html#a94e3346edf9d582c0fc48b57b831bcb5',1,'BCDtoBinary(uint8 *character, uint8 numChar):&#160;GlobalFunctions.h']]],
  ['binarytohex',['BinarytoHex',['../_global_functions_8c.html#a8ad361c0ad546131a7cb5b90d84a4a09',1,'BinarytoHex(uint8 character[], uint8 numChar):&#160;GlobalFunctions.c'],['../_global_functions_8h.html#a8ad361c0ad546131a7cb5b90d84a4a09',1,'BinarytoHex(uint8 character[], uint8 numChar):&#160;GlobalFunctions.c']]],
  ['blpe_5ffbe',['blpe_fbe',['../_m_c_g_8c.html#a3f4dbc1df066e720c81fe323dafba8c6',1,'blpe_fbe(int crystal_val):&#160;MCG.c'],['../_m_c_g_8h.html#a3f4dbc1df066e720c81fe323dafba8c6',1,'blpe_fbe(int crystal_val):&#160;MCG.c']]],
  ['blpe_5fpbe',['blpe_pbe',['../_m_c_g_8c.html#a08d92d0950d589fd18b19012957991f1',1,'blpe_pbe(int crystal_val, signed char prdiv_val, signed char vdiv_val):&#160;MCG.c'],['../_m_c_g_8h.html#a08d92d0950d589fd18b19012957991f1',1,'blpe_pbe(int crystal_val, signed char prdiv_val, signed char vdiv_val):&#160;MCG.c']]],
  ['blpi_5ffbi',['blpi_fbi',['../_m_c_g_8c.html#a671bd57a349f494b198d0b75cee747f4',1,'blpi_fbi(int irc_freq, unsigned char irc_select):&#160;MCG.c'],['../_m_c_g_8h.html#a671bd57a349f494b198d0b75cee747f4',1,'blpi_fbi(int irc_freq, unsigned char irc_select):&#160;MCG.c']]]
];
