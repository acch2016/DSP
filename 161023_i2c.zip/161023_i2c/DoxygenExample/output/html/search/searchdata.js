var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwy",
  1: "fgsu",
  2: "dfgilmnrsu",
  3: "abcdefghilmnprstuw",
  4: "abcfghimnpstu",
  5: "fgsu",
  6: "bfgikpstuv",
  7: "abcdefghiklmnprstuw",
  8: "abcdefghilmnoprstuwy",
  9: "st"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

