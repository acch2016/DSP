var searchData=
[
  ['terminal',['TERMINAL',['../menu_8h.html#a2592d55df52c5d125164dd15009d9584a9b2989c4ac8a0f9a7f46528384eaa5c7',1,'menu.h']]],
  ['true',['TRUE',['../_data_type_definitions_8h.html#a20f82124c82b6f5686a7fce454ef9089aa82764c3079aea4e60c80e45befbb839',1,'DataTypeDefinitions.h']]]
];
