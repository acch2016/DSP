var _i2_c_8c =
[
    [ "getModule_State", "_i2_c_8c.html#a177e862f34ce0dab4d55659013ec012b", null ],
    [ "I2C_BaudRate", "_i2_c_8c.html#a664cab50fe0f1cd43caa90cd60b38ac3", null ],
    [ "I2C_busy", "_i2_c_8c.html#a4d6d11a8f6f742078959006df6a7e11b", null ],
    [ "I2C_clockChannel", "_i2_c_8c.html#a26b928e0c820261eb17669d2362cd4a5", null ],
    [ "I2C_get_ACK", "_i2_c_8c.html#aa5a3b846186cda9225be84e16af84356", null ],
    [ "I2C_init", "_i2_c_8c.html#ad3debd22077c360e4160b99d091fe44c", null ],
    [ "I2C_MST_OrSLV_Mode", "_i2_c_8c.html#a2371441eff8976056f8ffbe086176783", null ],
    [ "I2C_NACK", "_i2_c_8c.html#aae489f3896588f59173688541155aa32", null ],
    [ "I2C_pinConfig", "_i2_c_8c.html#a814e6688339fc695fcc3655878389ff6", null ],
    [ "I2C_read_Byte", "_i2_c_8c.html#a689c3512503f9420b3d4fcd32ad6585f", null ],
    [ "I2C_repeted_Start", "_i2_c_8c.html#a577158ebfa27fcb673a5727e95d2d853", null ],
    [ "I2C_start", "_i2_c_8c.html#a09d9820de1e99617f206ef60a9a9d2e8", null ],
    [ "I2C_stop", "_i2_c_8c.html#a0635b74679cdb09c91ef36aa4181a911", null ],
    [ "I2C_TX_RX_Mode", "_i2_c_8c.html#a0f3ef5ef6878c9337e4bd8341628e42e", null ],
    [ "I2C_wait", "_i2_c_8c.html#a05143bfcf3eeb04ec1dfc7e4ab952689", null ],
    [ "I2C_write_Byte", "_i2_c_8c.html#a9b27c7aa55f8a11a274dd36b6f8a6d2f", null ],
    [ "I2Cx_C1", "_i2_c_8c.html#a71fa723431ccc734b756b4b85ad6e04f", null ],
    [ "I2Cx_D", "_i2_c_8c.html#a0a939e2bbd106151953f6cbc382111a1", null ],
    [ "I2Cx_F", "_i2_c_8c.html#aa5666203fd0b2b52d5ff432b6ef37c57", null ],
    [ "I2Cx_S", "_i2_c_8c.html#a6592252f4ef003e2e378f0140a711cf1", null ]
];