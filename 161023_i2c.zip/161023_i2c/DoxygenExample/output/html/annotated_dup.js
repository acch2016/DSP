var annotated_dup =
[
    [ "Flags", "union_flags.html", "union_flags" ],
    [ "FTM_ConfigType", "struct_f_t_m___config_type.html", "struct_f_t_m___config_type" ],
    [ "GPIOForSPIType", "struct_g_p_i_o_for_s_p_i_type.html", "struct_g_p_i_o_for_s_p_i_type" ],
    [ "SPI_ConfigType", "struct_s_p_i___config_type.html", "struct_s_p_i___config_type" ],
    [ "State", "struct_state.html", "struct_state" ],
    [ "StateLCD", "struct_state_l_c_d.html", "struct_state_l_c_d" ],
    [ "UART_MailBoxType", "struct_u_a_r_t___mail_box_type.html", "struct_u_a_r_t___mail_box_type" ]
];