var struct_s_p_i___config_type =
[
    [ "baudrate", "struct_s_p_i___config_type.html#a42f49748a986550b6398015dc5cd7c40", null ],
    [ "frameSize", "struct_s_p_i___config_type.html#aa2c1c5d6b1d6039c8bcb13652a4bba16", null ],
    [ "GPIOForSPI", "struct_s_p_i___config_type.html#abbc8299e8ac72f3d8145d07d8065b9f7", null ],
    [ "pinConttrolRegisterPORTD", "struct_s_p_i___config_type.html#ade104eedd8c53cf07378233e3aa06092", null ],
    [ "SPI_Channel", "struct_s_p_i___config_type.html#ae09a3a0be9756c9a02834592ccbbd505", null ],
    [ "SPI_EnableFIFO", "struct_s_p_i___config_type.html#a62da0169faa55b3f872d094dad1288b0", null ],
    [ "SPI_LSMorMSB", "struct_s_p_i___config_type.html#ab0d82c429ae61272760df3fff9061513", null ],
    [ "SPI_Master", "struct_s_p_i___config_type.html#a6d64386cb1375f99921b88ebd1473172", null ],
    [ "SPI_Phase", "struct_s_p_i___config_type.html#a0a13eb49b664d7b3bd0f8348c4520a99", null ],
    [ "SPI_Polarity", "struct_s_p_i___config_type.html#a0ffcdd0962ea071fa1ae1919f2a83276", null ]
];