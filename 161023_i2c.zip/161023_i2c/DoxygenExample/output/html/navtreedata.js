var NAVTREE =
[
  [ "PRACTICA3", "index.html", [
    [ "Sources", "md_C:_work_kin_161023_i2c_Sources_README.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_data_type_definitions_8h.html",
"_g_p_i_o_8h.html#ad00876d5583da5acf77eab647fb82bdb",
"_n_v_i_c_8h.html#a05657f3aa85721814ee368a0eded8513a48aa75a7893a8a15e3fa1f0e811a07b6",
"_u_a_r_t_8h.html#ac1c3e068363b8c659e70109d47c1db15"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';