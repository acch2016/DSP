var main_8c =
[
    [ "CLK0_TYPE", "main_8c.html#a57b23a4a08917373b6baaf44b7107627", null ],
    [ "CLK_FREQ_HZ", "main_8c.html#a89bf1cb7ece86f095f3809b15a60e29c", null ],
    [ "CRYSTAL_OSC", "main_8c.html#a0d4569f00223adb0ecf9698f4940b8d4", null ],
    [ "DEBUG", "main_8c.html#ad72dbcf6d0153db1b8d8a58001feed83", null ],
    [ "EXTERNAL_CLOCK", "main_8c.html#ae9d5d3d0882e298dbe8f4d5c5152c960", null ],
    [ "FAST_IRC_FREQ", "main_8c.html#a6fd785ecf523a29f0e9e4d5f131f7435", null ],
    [ "LOW_POWER", "main_8c.html#a35a08f33b3ae8fa5b76a37802c29bd05", null ],
    [ "PLL0_PRDIV", "main_8c.html#ac800eac792d5caba48d8b41096789958", null ],
    [ "PLL0_VDIV", "main_8c.html#aed05026be56da6ed2af1b3ee2e6b9eb6", null ],
    [ "PLL_DISABLE", "main_8c.html#ad0f602a92b7758dc258bd2616eb383e8", null ],
    [ "PLL_ENABLE", "main_8c.html#a9a5ad2abdb35e9541d6596722869220c", null ],
    [ "SLOW_IRC", "main_8c.html#ac63a4efd5c025b6504d40ff059a664a4", null ],
    [ "SLOW_IRC_FREQ", "main_8c.html#a1917266ca87eed67366cdc20bb1c5f0f", null ],
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "flag1", "main_8c.html#ab84f8862e040f449cf2bc8208f7f695b", null ],
    [ "Hours", "main_8c.html#ac3a79def3c3757f9c7cf336abb8cb29c", null ]
];