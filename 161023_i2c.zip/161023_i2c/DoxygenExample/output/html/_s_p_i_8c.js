var _s_p_i_8c =
[
    [ "SPI_clockPolarity", "_s_p_i_8c.html#af5744b76088520e4d616d70a67fa9374", null ],
    [ "SPI_enable", "_s_p_i_8c.html#aa8569eff93c8e6e683029aead54bc3ba", null ],
    [ "SPI_init", "_s_p_i_8c.html#aa72983bdb1bcfc055cea98c7501cc930", null ],
    [ "SPI_sendOneByte", "_s_p_i_8c.html#a8ca8cd04c9bc2ef898aee5d38b829642", null ],
    [ "SPI_startTranference", "_s_p_i_8c.html#a747d339e8353778bf7f8635a91d0a5f9", null ],
    [ "SPI_stopTranference", "_s_p_i_8c.html#a12e009cdc7cb64988ecf0814c3524f88", null ],
    [ "SPI_CTAR", "_s_p_i_8c.html#a6a4caf0b515498f176ea2c13e952cac1", null ],
    [ "SPIx_MCR", "_s_p_i_8c.html#a526c76fa6bc4a6ad5347d5b5243866fd", null ]
];