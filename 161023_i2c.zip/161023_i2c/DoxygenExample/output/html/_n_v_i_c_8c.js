var _n_v_i_c_8c =
[
    [ "NVIC_enableInterruptAndPriotity", "_n_v_i_c_8c.html#a1a4e74e5f147d23a9070d864c4f20606", null ],
    [ "NVIC_setBASEPRI_threshold", "_n_v_i_c_8c.html#adabcb6ba7492c49a19f0da49558394a5", null ]
];