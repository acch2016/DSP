/*
 * MotionSensor.c
 *
 *  Created on: 21/11/2016
 *      Author: Alexis
 */

#ifndef SOURCES_MOTIONSENSOR_C_
#define SOURCES_MOTIONSENSOR_C_





#endif /* SOURCES_MOTIONSENSOR_C_ */
