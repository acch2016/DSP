/*
 * SoundGen.c
 *
 *  Created on: 16/11/2016
 *      Author: Alexis
 */

#include "SoundGen.h"

void SoundGen_modifyFrecuency(uint8 frecuency, FTMType Timer, FTMChannelType channel){

}

void SoundGen_genFrecuency(uint8 frecuency, FTMType Timer, FTMChannelType channel){

}






